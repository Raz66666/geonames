<?php

declare(strict_types = 1);

$langs = [
    //'hy' => 'Հայերեն',
    'am' => 'Հայերեն',
    'en' => 'English',
    'ru' => 'Русский'
];
