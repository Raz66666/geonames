<?php

declare(strict_types = 1);

$CFG = [
    'charsets'    => 'cp1251 utf8 latin1',
    'lang'        => 'auto',
    'time_web'    => '600',
    'time_cron'   => '600',
    'backup_path' => 'backup/',
    'backup_url'  => 'backup/',
    'only_create' => 'MRG_MyISAM MERGE HEAP MEMORY',
    'globstat'    => 0,
    'my_host'     => '',
    'my_port'     => 3306,
    'my_user'     => 'root',
    'my_pass'     => '',
    'my_comp'     => 0,
    'my_db'       => '',
    'auth'        => 'mysql cfg',
    'user'        => '',
    'pass'        => '',
    'confirm'     => '6',
    'exitURL'     => './',
];
